# DESIGN.md

## Design Tokens

### 色彩
- 主色：绿色（emerald-600）
- Header：emerald-600 → green-600 渐变
- 在店：emerald 系
- 借出按钮：emerald-600
- 归还按钮：red-500
- 找回按钮：yellow-500
- 遗失状态：red 系

### 圆角
- 卡片：rounded-2xl
- 按钮/输入框：rounded-xl
- 统计卡片：rounded-2xl

### 尺寸
- 搜索框：h-12
- 弹窗输入框：h-11
- 操作按钮：h-11
- 卡片内边距：p-5/p-6

### 布局
- 卡片列表：grid-cols-1(手机) / grid-cols-2(平板) / grid-cols-3(电脑)
- 统计卡片：grid-cols-2(手机) / grid-cols-4(电脑)
- 最大宽度：max-w-6xl
