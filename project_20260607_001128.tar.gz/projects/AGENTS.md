# 钥匙管理系统 — 项目文档

## 项目简介

房地产中介门店钥匙管理系统，极简单页设计，帮助中介门店高效管理钥匙的借出、归还、遗失等日常操作。

核心功能：
- **统计看板**: 在店/借出/遗失数量一览
- **一键查询**: 按小区、房号、持有人、编号模糊搜索，按状态/小区筛选
- **一键改状态**: 借出（绿色）/归还（红色）/遗失/找回（黄色），卡片上直接操作
- **批量操作**: 批量借出/归还/标记遗失
- **添加钥匙**: 弹窗表单录入，钥匙编号下拉选择（1号-120号，已占用自动隐藏）
- **删除钥匙**: 确认弹窗防误删
- **钥匙图片**: 添加时上传图片，卡片展示缩略图

## 版本技术栈

| 项 | 版本 |
|---|---|
| Framework | Next.js 16 (App Router) |
| Core | React 19 |
| Language | TypeScript 5 |
| UI 组件 | shadcn/ui (基于 Radix UI) |
| Styling | Tailwind CSS 4 |
| Database | Supabase (PostgreSQL) |
| 对象存储 | S3 兼容存储 (coze-coding-dev-sdk) |
| 包管理 | pnpm（严禁 npm/yarn） |

## 目录结构

```
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   ├── keys/
│   │   │   │   ├── route.ts              # GET 列表+统计, POST 添加
│   │   │   │   ├── [id]/route.ts          # PATCH 状态变更, DELETE 删除
│   │   │   │   ├── batch/route.ts         # POST 批量操作
│   │   │   │   └── upload-image/route.ts  # POST 图片上传到 S3
│   │   │   └── image-url/
│   │   │       └── route.ts              # GET 生成图片签名访问 URL
│   │   ├── globals.css                   # 全局样式（绿色主题 CSS 变量）
│   │   ├── layout.tsx                    # 根布局（metadata: 钥匙管理）
│   │   ├── page.tsx                      # 单页面（统计+搜索+卡片列表+弹窗）
│   │   └── robots.ts
│   ├── components/ui/                    # shadcn/ui 组件库
│   ├── hooks/
│   │   └── use-mobile.ts
│   ├── storage/database/
│   │   ├── supabase-client.ts            # Supabase 客户端（自动获取凭证）
│   │   └── shared/
│   │       ├── schema.ts                 # keys + key_logs 表定义
│   │       └── relations.ts
│   └── lib/utils.ts
├── .coze                                 # 构建部署配置
├── AGENTS.md                             # 本文件
├── DESIGN.md                             # 设计规范
└── package.json
```

---

## 数据库 Schema

### keys 表（主表）

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| id | varchar(36) PK | 自动 | UUID (gen_random_uuid) |
| community | varchar(128) | 是 | 小区名称 |
| building | varchar(64) | 否 | 楼栋 |
| unit | varchar(64) | 否 | 单元（历史字段，前端未使用） |
| room | varchar(64) | 是 | 房间号 |
| address | varchar(256) | 是 | 完整地址（自动拼接 community+building+room） |
| key_number | varchar(64) | 是 | 钥匙编号（如"1号"，有唯一约束） |
| key_type | varchar(32) | 是 | 类型：机械钥匙 / 密码卡片（默认机械钥匙） |
| quantity | integer | 是 | 数量（默认1） |
| status | varchar(16) | 是 | 状态：在店 / 借出 / 遗失（默认在店） |
| cabinet_number | varchar(32) | 否 | 柜号 |
| holder | varchar(64) | 否 | 当前持有人（借出时有值） |
| notes | varchar(512) | 否 | 备注 |
| image_key | varchar(512) | 否 | S3 图片 key（非 URL） |
| created_at | timestamp | 自动 | 创建时间 |
| updated_at | timestamp | 自动 | 更新时间 |

**索引**: status, community, holder
**唯一约束**: key_number（WHERE key_number IS NOT NULL，部分索引，允许 NULL 但非 NULL 值必须唯一）

### key_logs 表（后台静默记录，前端不展示）

| 字段 | 类型 | 说明 |
|------|------|------|
| id | varchar(36) PK | UUID |
| key_id | varchar(36) FK | 关联 keys.id (CASCADE DELETE) |
| action | varchar(32) | 操作：借出 / 归还 / 标记遗失 |
| from_status | varchar(16) | 原状态 |
| to_status | varchar(16) | 新状态 |
| reason | varchar(512) | 原因/备注 |
| created_at | timestamp | 操作时间 |

**索引**: key_id, created_at

---

## API 接口

### 1. GET /api/keys — 钥匙列表 + 统计 + 小区列表

**Query 参数**:
| 参数 | 类型 | 说明 |
|------|------|------|
| keyword | string | 模糊搜索（小区/房号/持有人/编号），后端用 ilike 做 OR 查询 |
| status | string | 状态筛选：在店/借出/遗失 |
| community | string | 小区筛选 |

**返回**:
```json
{
  "success": true,
  "data": {
    "keys": [...],
    "total": 10,
    "stats": { "total": 10, "inStore": 6, "borrowed": 3, "lost": 1 },
    "communities": ["翠湖花园", "阳光城邦"]
  }
}
```

**逻辑**:
- 三个筛选条件联动，任一条件变化都会重新查询
- stats 统计不受筛选条件影响，始终返回全量统计
- communities 从 keys 表中去重提取，用于前端小区下拉
- 按 created_at 降序排列

### 2. POST /api/keys — 添加钥匙

**Body**:
```json
{
  "community": "翠湖花园",    // 必填
  "building": "A栋",          // 可选
  "room": "101",              // 必填
  "key_number": "1号",        // 必填，唯一
  "key_type": "机械钥匙",      // 默认机械钥匙
  "quantity": 1,               // 默认1
  "cabinet_number": "A-01",   // 可选
  "notes": "精装三房",         // 可选
  "image_key": "keys/xxx.jpg" // 可选，S3 key
}
```

**逻辑**:
- 自动生成 address 字段（community + building + room 拼接）
- key_number 唯一校验：先查库 + 数据库唯一约束双重保障
- 应用层先 `.select().eq('key_number', xxx).maybeSingle()` 查询是否已存在
- 若已存在，返回 400 + `"钥匙编号 X号 已存在"`
- 数据库层 `keys_key_number_not_null_key` 唯一索引兜底，捕获 duplicate key 异常也返回 400 友好提示
- 默认 status="在店"，默认 key_type="机械钥匙"，默认 quantity=1

### 3. PATCH /api/keys/[id] — 单个状态变更

**Body**: `{ "status": "借出" }` 或 `{ "status": "在店" }` 或 `{ "status": "遗失" }`
- holder 为可选参数，借出时可传可不传
- 归还（status→在店）：自动清空 holder
- 遗失：不清空 holder
- 自动记录 key_logs（action, from_status, to_status）
- 静默更新 updated_at

**状态流转规则**:
```
在店 ──借出──→ 借出
在店 ──遗失──→ 遗失
借出 ──归还──→ 在店
借出 ──遗失──→ 遗失
遗失 ──找回──→ 在店
```

### 4. DELETE /api/keys/[id] — 删除钥匙

- 物理删除，key_logs 通过 CASCADE 自动清理
- 前端二次确认防误删
- 删除后 key_number 自动释放回可选列表（前端重新计算 usedKeyNumbers）

### 5. POST /api/keys/batch — 批量操作

**Body**:
```json
{
  "ids": ["key-001", "key-002"],  // 必填，ID 数组
  "status": "借出",               // 必填
  "holder": "张经理"              // 可选
}
```

**逻辑**:
- 支持批量借出/归还/遗失
- 归还自动清空所有选中钥匙的 holder
- 遍历 ids 数组，逐个更新 status + holder，逐个记录 key_logs
- 返回更新后的钥匙数组

### 6. POST /api/keys/upload-image — 图片上传

**请求**: FormData，字段名 `image`
- 支持 JPG/PNG/WebP/GIF
- 最大 5MB，超过返回 400
- 文件类型校验，不支持的类型返回 400
- 上传到 S3 对象存储，路径: `keys/{timestamp}.{ext}`
- 使用 coze-coding-dev-sdk 的 StorageClient

**返回**: `{ "success": true, "data": { "image_key": "keys/1234567890.jpg" } }`

### 7. GET /api/image-url — 获取图片签名 URL

**Query**: `key=keys/1234567890.jpg`
- 根据 image_key 生成预签名 URL
- 签名 URL 有效期 24 小时
- 前端缓存 URL 到 imageUrls state，避免频繁请求

**返回**: `{ "success": true, "data": { "url": "https://...signed-url..." } }`

---

## 前端功能详解

### 整体架构

单页面应用（`page.tsx`），`"use client"` 组件，所有功能集成在一个文件中，无需路由跳转。

页面从上到下结构：
1. 绿色渐变 Header（标题"钥匙管理"）
2. 统计看板（4 个统计卡片）
3. 搜索筛选栏（搜索框 + 筛选 + 按钮）
4. 批量操作栏（批量模式下显示）
5. 钥匙卡片网格列表
6. 添加钥匙弹窗
7. 删除确认弹窗

### 一、统计看板

**展示内容**：4 个统计卡片

| 卡片 | 颜色 | 说明 |
|------|------|------|
| 总计 | 绿色边框 (border-emerald-200) | 所有钥匙总数 |
| 在店 | 绿色边框 (border-emerald-200) | 状态为"在店"的数量 |
| 借出 | 橙色边框 (border-orange-200) | 状态为"借出"的数量 |
| 遗失 | 红色边框 (border-red-200) | 状态为"遗失"的数量 |

**数据来源**：每次搜索/筛选时，`GET /api/keys` 接口返回的 `stats` 字段
**响应式**：手机 2 列（grid-cols-2），电脑 4 列（lg:grid-cols-4）

### 二、搜索与筛选栏

**搜索框**：
- 大号输入框（h-12），左侧搜索图标
- 输入内容自动触发搜索（keyword 参数传给后端）
- 后端用 ilike 做 OR 模糊匹配，覆盖字段：community, room, holder, key_number

**状态筛选**：
- Select 下拉，选项：全部 / 在店 / 借出 / 遗失
- 选中后自动筛选

**小区筛选**：
- Select 下拉，选项从 `GET /api/keys` 返回的 communities 动态生成
- 选项：全部小区 / 各小区名称

**操作按钮**：
- "+ 添加钥匙"：绿色按钮，点击打开添加钥匙弹窗
- "批量操作"：默认显示，点击进入批量模式；批量模式下变为"取消批量"

**联动逻辑**：
- 搜索、状态筛选、小区筛选三者联动
- 任一条件变化 → 重新调用 `fetchKeys()` → 返回过滤后的钥匙列表 + 更新后的统计
- 搜索有 300ms 防抖（通过 setTimeout + clearTimeout 实现）

**响应式**：
- 手机：搜索框独占一行，筛选和按钮第二行
- 电脑：所有元素一行排列

### 三、批量操作模式

**进入/退出**：
- 点击"批量操作"按钮 → 进入多选模式（`batchMode = true`）
- 点击"取消批量" → 退出（`batchMode = false`，清空 `selected` Set）

**选择机制**：
- 每张钥匙卡片左上角出现 Checkbox，点击勾选/取消
- 顶部有"全选"Checkbox 和"已选 X 项"计数
- 选中的卡片有绿色高亮边框（`ring-2 ring-emerald-400`）
- 全选逻辑：遍历当前页面所有 keys，全部选中则全选框打勾

**批量操作按钮**（选中 ≥1 项后才可点击）：
| 按钮 | 颜色 | 功能 |
|------|------|------|
| 批量借出 | 绿色 (bg-emerald-600) | 状态改为"借出" |
| 批量归还 | 红色 (bg-red-500) | 状态改为"在店"，清空持有人 |
| 批量遗失 | 红色destructive | 状态改为"遗失" |

**接口调用**：`POST /api/keys/batch`，传入 `ids` 数组（从 `selected` Set 转换）和目标 `status`

**完成后**：清空 selected、退出批量模式、刷新钥匙列表

### 四、钥匙卡片

每把钥匙一张卡片（rounded-2xl, shadow-sm, hover:shadow-md 过渡），内容从上到下：

**a. 钥匙图片**（有 image_key 时显示）
- 卡片顶部，圆角缩略图，宽度100%，高度 160px（h-40），object-cover
- 图片 URL 通过 `GET /api/image-url?key=xxx` 获取签名 URL
- 前端用 `imageUrls` state（Record<string, string>）缓存 URL，避免重复请求
- 图片加载流程：keys 列表加载后 → useEffect 遍历有 image_key 的钥匙 → 并发请求签名 URL → 存入 imageUrls state → 卡片自动渲染

**b. 头行**：小区名 + 状态标签
- 小区名：大字加粗（text-lg sm:text-xl font-bold），批量模式下左侧有 Checkbox
- 状态标签：圆角 badge（text-sm font-semibold px-3 py-1 rounded-full border）
  - 在店：绿色底（bg-emerald-50 text-emerald-700 border-emerald-200）
  - 借出：橙色底（bg-orange-50 text-orange-700 border-orange-200）
  - 遗失：红色底（bg-red-50 text-red-700 border-red-200）

**c. 信息区**（2 列 grid，gap-x-4 gap-y-3）：

| 字段 | 样式 | 特殊说明 |
|------|------|---------|
| 楼栋 | text-base sm:text-lg font-semibold | 无值显示"-" |
| 房号 | text-base sm:text-lg font-semibold | - |
| 编号 | text-base sm:text-lg font-semibold text-emerald-700 | 绿色高亮 |
| 类型 | text-base sm:text-lg font-semibold | 带 emoji 前缀：🔑 机械钥匙 / 💳 密码卡片 |
| 数量 | text-base sm:text-lg font-semibold | - |
| 持有人 | text-base sm:text-lg font-semibold text-orange-600 | 仅借出状态且 holder 有值时显示 |

**d. 备注区**（有 notes 时显示）
- 灰色底圆角区域（bg-gray-50 rounded-xl px-3 py-2）
- 小标签"备注" + 备注内容（text-sm text-gray-600 break-all）

**e. 操作按钮**（非批量模式才显示，flex gap-2 flex-wrap）

| 当前状态 | 可用操作 | 按钮样式 |
|---------|---------|---------|
| 在店 | 借出 + 遗失 + 删除 | 绿色大按钮 + 红色outline + 灰色ghost |
| 借出 | 归还 + 遗失 + 删除 | 红色大按钮 + 红色outline + 灰色ghost |
| 遗失 | 找回 + 删除 | 黄色大按钮 + 灰色ghost |

- 操作按钮高度 h-11，圆角 rounded-xl，字体 text-base font-semibold
- 主要操作（借出/归还/找回）为实心按钮，flex-1 min-w-[80px]
- 遗失为 outline 按钮，红色边框
- 删除为 ghost 按钮，灰色文字，hover 变红

**卡片布局响应式**：
- 手机：grid-cols-1
- 平板（sm）：grid-cols-2
- 电脑（lg）：grid-cols-3

### 五、添加钥匙弹窗

**触发**：点击搜索栏右侧绿色"+ 添加钥匙"按钮

**弹窗表单**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| 小区 | 文本输入 (Input) | 是 | placeholder "如 翠湖花园" |
| 楼栋 | 文本输入 (Input) | 否 | placeholder "如 A栋" |
| 房号 | 文本输入 (Input) | 是 | placeholder "如 101" |
| 钥匙编号 | 下拉选择 (Select) | 是 | 1号-120号，已占用编号不显示 |
| 类型 | 下拉选择 (Select) | 否 | 🔑 机械钥匙（默认）/ 💳 密码卡片 |
| 数量 | 数字输入 (Input number) | 否 | 默认1，min=1 |
| 柜号 | 文本输入 (Input) | 否 | placeholder "可选" |
| 钥匙图片 | 文件上传 | 否 | 虚线框点击选择，预览+删除 |
| 备注 | 多行文本 (Textarea) | 否 | rows=2，placeholder "可选，如密码信息等" |

**弹窗布局**：
- 最大宽度 sm:max-w-md，圆角 rounded-2xl
- 小区+楼栋一行两列（grid-cols-2 gap-4）
- 房号+编号一行两列
- 类型+数量一行两列
- 柜号、图片、备注各独占一行
- 底部：取消按钮 + 确认添加按钮（绿色 bg-emerald-600）

**钥匙编号下拉逻辑**：
1. 前端生成 1号 到 120 号共 120 个选项
2. 从当前钥匙列表中提取所有已占用的 key_number，组成 `usedKeyNumbers` Set
3. 过滤掉已占用的编号，得到 `availableKeyNumbers` 数组
4. 已占用的编号不在下拉中显示
5. 删除钥匙后，列表刷新 → usedKeyNumbers 重新计算 → 编号自动回到可选项
6. 全部 120 个编号都被占用时，下拉显示"已无可用编号"（disabled 项）

**图片上传流程**：
1. 点击虚线框（80x80px，border-dashed）→ 触发隐藏的 file input
2. 选择图片文件（accept: image/jpeg,image/png,image/webp,image/gif）
3. `FileReader.readAsDataURL()` → 本地即时预览缩略图（80x80 圆角）
4. 同时创建 `FormData`，POST 到 `/api/keys/upload-image`
5. 上传中显示"上传中..."文字
6. 上传成功后返回 `image_key`，保存到 `imageKey` state
7. 预览图右上角有 x 按钮，点击删除图片（清空 imageKey 和 imagePreview）
8. 弹窗关闭时自动重置图片状态（imageKey=null, imagePreview=null）

**提交逻辑**：
1. 校验小区、房号、钥匙编号三个必填项（按钮 disabled 条件）
2. 调用 `POST /api/keys`，传入表单数据 + image_key
3. 后端双重校验钥匙编号唯一性（先查询 + 数据库唯一约束）
4. 重复编号返回 400 + `"钥匙编号 X号 已存在"`，前端 toast 提示
5. 添加成功后：关闭弹窗、重置表单（form 回到默认值）、重置图片状态、刷新列表

### 六、删除确认弹窗

**触发**：卡片底部"删除"按钮（灰色 ghost 样式）

**弹窗内容**：
- 标题："确认删除"
- 描述文字："确定要删除 XXX小区 X栋 XXX房 的钥匙吗？此操作不可撤销。"
- 取消按钮（outline 样式）+ 确认删除按钮（destructive 红色样式）

**接口调用**：`DELETE /api/keys/[id]`

**完成后**：关闭弹窗（showDelete=null）、刷新列表，该钥匙编号自动释放回可选列表

---

## 图片功能完整流程

### 上传流程
```
用户点击虚线框 → 选择图片文件
  → FileReader.readAsDataURL() → 本地即时预览
  → FormData POST /api/keys/upload-image
    → StorageClient.upload() 上传到 S3
    → 返回 image_key（如 "keys/1714660800000.jpg"）
  → imageKey state 保存 S3 key
  → 添加钥匙时 image_key 随表单一起提交
```

### 展示流程
```
页面加载 → fetchKeys() 获取钥匙列表
  → useEffect 遍历有 image_key 的钥匙
  → 并发请求 GET /api/image-url?key=xxx
    → StorageClient.getSignedUrl() 生成预签名 URL（24h 有效）
    → 返回签名 URL
  → 存入 imageUrls state（Record<string, string>）
  → 卡片根据 image_key 从 imageUrls 取 URL 渲染 <img>
```

### 存储策略
- 数据库存 `image_key`（S3 存储路径），不存 URL
- 签名 URL 24 小时有效期，过期需重新获取
- 前端 `imageUrls` state 缓存，同一次页面访问内不重复请求
- S3 文件路径格式：`keys/{timestamp}.{ext}`

---

## 状态流转图

```
         借出              归还
  在店 ───────→ 借出 ───────→ 在店
   │              │              ↑
   │遗失          │遗失          │找回
   ↓              ↓              │
  遗失 ←─────────┘──────────────┘

  任何状态 → 删除（物理删除，不可恢复）
```

---

## 前端 State 管理

| State | 类型 | 说明 |
|-------|------|------|
| keys | KeyItem[] | 当前钥匙列表 |
| stats | { total, inStore, borrowed, lost } | 统计数据 |
| communities | string[] | 小区下拉选项 |
| keyword | string | 搜索关键词 |
| statusFilter | string | 状态筛选值 |
| communityFilter | string | 小区筛选值 |
| loading | boolean | 加载状态 |
| batchMode | boolean | 是否批量模式 |
| selected | Set\<string\> | 批量选中的钥匙 ID |
| showAdd | boolean | 显示添加钥匙弹窗 |
| showDelete | KeyItem \| null | 显示删除确认弹窗（null 为关闭） |
| form | FormType | 添加钥匙表单数据 |
| imagePreview | string \| null | 图片本地预览 Data URL |
| imageKey | string \| null | 图片上传后的 S3 key |
| uploading | boolean | 图片上传中状态 |
| imageUrls | Record\<string, string\> | 签名 URL 缓存 |

---

## 设计规范

| 项目 | 规范 |
|------|------|
| 主色调 | 绿色（emerald-600） |
| Header | 绿色渐变 (emerald-600 → green-600) |
| 添加钥匙按钮 | 绿色 (bg-emerald-600) |
| 借出按钮 | 绿色 (bg-emerald-600) |
| 找回按钮 | 黄色 (bg-yellow-500) |
| 归还按钮 | 红色 (bg-red-500) |
| 遗失按钮 | 红色 outline (border-red-200) |
| 删除按钮 | 灰色 ghost (text-gray-400) |
| 卡片圆角 | rounded-2xl |
| 按钮圆角 | rounded-xl |
| 输入框圆角 | rounded-xl |
| 弹窗圆角 | rounded-2xl |
| 搜索框高度 | h-12 |
| 弹窗输入框高度 | h-11 |
| 操作按钮高度 | h-11 |
| 卡片布局 | grid-cols-1(sm) / grid-cols-2(md) / grid-cols-3(lg) |
| 统计布局 | grid-cols-2 / lg:grid-cols-4 |

---

## 开发规范

- 字段名使用 snake_case（与数据库一致）
- Supabase 操作必须检查 `{ data, error }` 并 throw
- `.delete()` / `.update()` 必须带 filter
- 禁止隐式 `any`
- 禁止在 JSX 中使用 typeof window / Date.now()，用 'use client' + useEffect
- DialogContent 必须加 `aria-describedby={undefined}`
- 图片存储用 S3 对象存储（存 key 非 URL），签名 URL 按需生成
- key_number 唯一性：应用层校验 + 数据库唯一约束双重保障

---

## 构建命令

```bash
pnpm install         # 安装依赖
pnpm ts-check        # TypeScript 类型检查
pnpm lint:build      # ESLint 检查
pnpm build           # 构建
pnpm dev             # 开发环境（端口 5000）
pnpm start           # 生产环境
```
