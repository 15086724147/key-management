"use client";

import { useState, useEffect, useCallback, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";

/* ───── Types ───── */
interface KeyItem {
  id: string;
  community: string;
  building: string | null;
  room: string;
  key_number: string | null;
  key_type: string;
  quantity: number;
  status: string;
  cabinet_number: string | null;
  holder: string | null;
  notes: string | null;
  image_key: string | null;
}

interface Stats {
  total: number;
  inStore: number;
  borrowed: number;
  lost: number;
}

/* ───── Page ───── */
export default function HomePage() {
  const [keys, setKeys] = useState<KeyItem[]>([]);
  const [stats, setStats] = useState<Stats>({ total: 0, inStore: 0, borrowed: 0, lost: 0 });
  const [communities, setCommunities] = useState<string[]>([]);
  const [keyword, setKeyword] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterCommunity, setFilterCommunity] = useState("all");
  const [loading, setLoading] = useState(true);

  // 批量选择
  const [batchMode, setBatchMode] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());

  // 弹窗
  const [showAdd, setShowAdd] = useState(false);
  const [showDelete, setShowDelete] = useState<KeyItem | null>(null);

  // 图片上传
  const [uploading, setUploading] = useState(false);
  const [imageKey, setImageKey] = useState<string | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  // 钥匙图片URL缓存
  const [imageUrls, setImageUrls] = useState<Record<string, string>>({});

  // 添加表单
  const [form, setForm] = useState({
    community: "",
    building: "",
    room: "",
    key_number: "",
    key_type: "机械钥匙",
    quantity: 1,
    cabinet_number: "",
    notes: "",
  });

  /* fetch */
  const fetchKeys = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (keyword) params.set("keyword", keyword);
      if (filterStatus !== "all") params.set("status", filterStatus);
      if (filterCommunity !== "all") params.set("community", filterCommunity);
      const res = await fetch(`/api/keys?${params}`);
      const json = await res.json();
      if (json.success) {
        setKeys(json.data.keys);
        setStats(json.data.stats);
        setCommunities(json.data.communities);
      }
    } finally {
      setLoading(false);
    }
  }, [keyword, filterStatus, filterCommunity]);

  useEffect(() => {
    fetchKeys();
  }, [fetchKeys]);

  /* 加载钥匙图片URL */
  useEffect(() => {
    const loadImages = async () => {
      const keysWithImages = keys.filter((k) => k.image_key && !imageUrls[k.image_key]);
      if (keysWithImages.length === 0) return;
      const newUrls: Record<string, string> = {};
      await Promise.all(
        keysWithImages.map(async (k) => {
          if (!k.image_key) return;
          try {
            const res = await fetch(`/api/image-url?key=${encodeURIComponent(k.image_key)}`);
            const json = await res.json();
            if (json.success) newUrls[k.image_key] = json.data.url;
          } catch { /* ignore */ }
        })
      );
      if (Object.keys(newUrls).length > 0) {
        setImageUrls((prev) => ({ ...prev, ...newUrls }));
      }
    };
    loadImages();
  }, [keys]); // eslint-disable-line react-hooks/exhaustive-deps

  /* 已占用的钥匙编号集合 */
  const usedKeyNumbers = useMemo(() => {
    const used = new Set<string>();
    keys.forEach((k) => {
      if (k.key_number) used.add(k.key_number);
    });
    return used;
  }, [keys]);

  /* 可选的钥匙编号 (1-120，去掉已占用的) */
  const availableKeyNumbers = useMemo(() => {
    const nums: string[] = [];
    for (let i = 1; i <= 120; i++) {
      const numStr = `${i}号`;
      if (!usedKeyNumbers.has(numStr)) {
        nums.push(numStr);
      }
    }
    return nums;
  }, [usedKeyNumbers]);

  /* helpers */
  const statusBadge: Record<string, string> = {
    "在店": "bg-emerald-100 text-emerald-700 border-emerald-200",
    "借出": "bg-orange-100 text-orange-700 border-orange-200",
    "遗失": "bg-red-100 text-red-600 border-red-200",
  };

  const keyTypeIcon: Record<string, string> = {
    "机械钥匙": "🔑",
    "密码卡片": "💳",
  };

  /* 状态变更 */
  const changeStatus = async (id: string, status: string) => {
    await fetch(`/api/keys/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    fetchKeys();
  };

  /* 批量操作 */
  const batchAction = async (status: string) => {
    await fetch("/api/keys/batch", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ids: [...selected], status }),
    });
    setSelected(new Set());
    setBatchMode(false);
    fetchKeys();
  };

  /* 添加钥匙 */
  const addKey = async () => {
    if (!form.community || !form.room || !form.key_number) return;
    await fetch("/api/keys", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...form, image_key: imageKey }),
    });
    setShowAdd(false);
    setForm({
      community: "",
      building: "",
      room: "",
      key_number: "",
      key_type: "机械钥匙",
      quantity: 1,
      cabinet_number: "",
      notes: "",
    });
    setImageKey(null);
    setImagePreview(null);
    fetchKeys();
  };

  /* 图片上传 */
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    // 预览
    const reader = new FileReader();
    reader.onload = (ev) => setImagePreview(ev.target?.result as string);
    reader.readAsDataURL(file);
    // 上传
    setUploading(true);
    try {
      const formData = new FormData();
      formData.append("image", file);
      const res = await fetch("/api/keys/upload-image", { method: "POST", body: formData });
      const json = await res.json();
      if (json.success) {
        setImageKey(json.data.image_key);
      }
    } finally {
      setUploading(false);
    }
  };

  /* 删除 */
  const deleteKey = async (id: string) => {
    await fetch(`/api/keys}/${id}`, { method: "DELETE" });
    setShowDelete(null);
    fetchKeys();
  };

  /* 选中切换 */
  const toggleSelect = (id: string) => {
    const s = new Set(selected);
    if (s.has(id)) s.delete(id);
    else s.add(id);
    setSelected(s);
  };

  const selectAll = () => {
    if (selected.size === keys.length) {
      setSelected(new Set());
    } else {
      setSelected(new Set(keys.map((k) => k.id)));
    }
  };

  /* ───── Render ───── */
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header - 绿色 */}
      <header className="bg-gradient-to-r from-emerald-600 to-green-600 text-white shadow-lg">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">🔑 钥匙管理</h1>
          <p className="text-white/70 mt-1 text-sm sm:text-base">房地产中介门店钥匙管理系统</p>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 sm:px-6 -mt-4 pb-16">
        {/* 统计卡片 */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 mb-6">
          {[
            { label: "总计", value: stats.total, bg: "bg-white", border: "border-emerald-200", text: "text-emerald-700" },
            { label: "在店", value: stats.inStore, bg: "bg-white", border: "border-emerald-200", text: "text-emerald-600" },
            { label: "借出", value: stats.borrowed, bg: "bg-white", border: "border-orange-200", text: "text-orange-600" },
            { label: "遗失", value: stats.lost, bg: "bg-white", border: "border-red-200", text: "text-red-500" },
          ].map((s) => (
            <div key={s.label} className={`${s.bg} ${s.border} border rounded-2xl p-4 sm:p-5 text-center shadow-sm`}>
              <div className={`text-2xl sm:text-4xl font-bold ${s.text}`}>{s.value}</div>
              <div className="text-xs sm:text-sm text-muted-foreground mt-1">{s.label}</div>
            </div>
          ))}
        </div>

        {/* 搜索 + 筛选 + 操作 */}
        <div className="bg-white rounded-2xl border shadow-sm p-4 sm:p-5 mb-6 space-y-4">
          {/* 搜索行 */}
          <div className="flex flex-col sm:flex-row gap-3">
            <Input
              placeholder="搜索小区、房号..."
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              className="h-12 text-base rounded-xl flex-1"
            />
            <Button
              size="lg"
              className="h-12 px-6 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold shrink-0 text-base"
              onClick={() => setShowAdd(true)}
            >
              + 添加钥匙
            </Button>
          </div>

          {/* 筛选行 */}
          <div className="flex flex-wrap gap-3 items-center">
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-28 sm:w-32 h-10 rounded-xl">
                <SelectValue placeholder="状态" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部状态</SelectItem>
                <SelectItem value="在店">在店</SelectItem>
                <SelectItem value="借出">借出</SelectItem>
                <SelectItem value="遗失">遗失</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterCommunity} onValueChange={setFilterCommunity}>
              <SelectTrigger className="w-36 sm:w-44 h-10 rounded-xl">
                <SelectValue placeholder="小区" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部小区</SelectItem>
                {communities.map((c) => (
                  <SelectItem key={c} value={c}>
                    {c}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="flex-1" />
            <Button
              variant={batchMode ? "default" : "outline"}
              className={`h-10 rounded-xl ${batchMode ? "bg-emerald-600 hover:bg-emerald-700 text-white" : ""}`}
              onClick={() => {
                setBatchMode(!batchMode);
                setSelected(new Set());
              }}
            >
              {batchMode ? "取消批量" : "批量操作"}
            </Button>
          </div>

          {/* 批量操作栏 */}
          {batchMode && (
            <div className="flex flex-wrap gap-3 items-center pt-3 border-t">
              <Checkbox
                checked={selected.size === keys.length && keys.length > 0}
                onCheckedChange={selectAll}
              />
              <span className="text-sm text-muted-foreground">全选</span>
              <span className="text-sm text-muted-foreground">已选 {selected.size} 项</span>
              <div className="flex-1" />
              <Button
                size="lg"
                className="h-10 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white px-5"
                disabled={selected.size === 0}
                onClick={() => batchAction("借出")}
              >
                批量借出
              </Button>
              <Button
                size="lg"
                className="h-10 rounded-xl bg-red-500 hover:bg-red-600 text-white px-5"
                disabled={selected.size === 0}
                onClick={() => batchAction("在店")}
              >
                批量归还
              </Button>
              <Button
                size="lg"
                variant="destructive"
                className="h-10 rounded-xl px-5"
                disabled={selected.size === 0}
                onClick={() => batchAction("遗失")}
              >
                批量遗失
              </Button>
            </div>
          )}
        </div>

        {/* 钥匙卡片列表 */}
        {loading ? (
          <div className="text-center py-20 text-muted-foreground text-lg">加载中...</div>
        ) : keys.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground text-lg">暂无钥匙数据</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {keys.map((key) => (
              <div
                key={key.id}
                className={`bg-white rounded-2xl border shadow-sm p-5 sm:p-6 transition-all hover:shadow-md ${
                  selected.has(key.id) ? "ring-2 ring-emerald-400 border-emerald-300" : ""
                }`}
              >
                {/* 钥匙图片 */}
                {key.image_key && imageUrls[key.image_key] && (
                  <div className="mb-4 rounded-xl overflow-hidden">
                    <img
                      src={imageUrls[key.image_key]}
                      alt="钥匙图片"
                      className="w-full h-40 object-cover"
                    />
                  </div>
                )}

                {/* 头行：小区 + 状态标签 */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2 min-w-0">
                    {batchMode && (
                      <Checkbox
                        checked={selected.has(key.id)}
                        onCheckedChange={() => toggleSelect(key.id)}
                        className="shrink-0"
                      />
                    )}
                    <span className="text-lg sm:text-xl font-bold text-foreground truncate">
                      {key.community}
                    </span>
                  </div>
                  <span
                    className={`text-sm font-semibold px-3 py-1 rounded-full border whitespace-nowrap ${statusBadge[key.status] || ""}`}
                  >
                    {key.status}
                  </span>
                </div>

                {/* 信息区 - 大字 */}
                <div className="grid grid-cols-2 gap-x-4 gap-y-3 mb-4">
                  <div>
                    <div className="text-xs text-muted-foreground mb-0.5">楼栋</div>
                    <div className="text-base sm:text-lg font-semibold">{key.building || "-"}</div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground mb-0.5">房号</div>
                    <div className="text-base sm:text-lg font-semibold">{key.room}</div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground mb-0.5">编号</div>
                    <div className="text-base sm:text-lg font-semibold text-emerald-700">
                      {key.key_number || "-"}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground mb-0.5">类型</div>
                    <div className="text-base sm:text-lg font-semibold">
                      {keyTypeIcon[key.key_type] || "🔑"} {key.key_type}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground mb-0.5">数量</div>
                    <div className="text-base sm:text-lg font-semibold">{key.quantity}</div>
                  </div>
                  {key.status === "借出" && key.holder && (
                    <div>
                      <div className="text-xs text-muted-foreground mb-0.5">持有人</div>
                      <div className="text-base sm:text-lg font-semibold text-orange-600">
                        {key.holder}
                      </div>
                    </div>
                  )}
                </div>

                {/* 备注 */}
                {key.notes && (
                  <div className="bg-gray-50 rounded-xl px-3 py-2 mb-4">
                    <div className="text-xs text-muted-foreground mb-0.5">备注</div>
                    <div className="text-sm text-gray-600 break-all">{key.notes}</div>
                  </div>
                )}

                {/* 操作按钮 - 大按钮 */}
                {!batchMode && (
                  <div className="flex gap-2 flex-wrap">
                    {key.status === "在店" && (
                      <Button
                        className="flex-1 min-w-[80px] h-11 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-base"
                        onClick={() => changeStatus(key.id, "借出")}
                      >
                        借出
                      </Button>
                    )}
                    {key.status === "借出" && (
                      <Button
                        className="flex-1 min-w-[80px] h-11 rounded-xl bg-red-500 hover:bg-red-600 text-white font-semibold text-base"
                        onClick={() => changeStatus(key.id, "在店")}
                      >
                        归还
                      </Button>
                    )}
                    {key.status !== "遗失" && (
                      <Button
                        variant="outline"
                        className="h-11 rounded-xl text-red-500 border-red-200 hover:bg-red-50 font-semibold text-base"
                        onClick={() => changeStatus(key.id, "遗失")}
                      >
                        遗失
                      </Button>
                    )}
                    {key.status === "遗失" && (
                      <Button
                        className="flex-1 min-w-[80px] h-11 rounded-xl bg-yellow-500 hover:bg-yellow-600 text-white font-semibold text-base"
                        onClick={() => changeStatus(key.id, "在店")}
                      >
                        找回
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      className="h-11 rounded-xl text-gray-400 hover:text-red-500 shrink-0 text-base"
                      onClick={() => setShowDelete(key)}
                    >
                      删除
                    </Button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </main>

      {/* ─── 添加钥匙弹窗 ─── */}
      <Dialog open={showAdd} onOpenChange={(open) => { setShowAdd(open); if (!open) { setImageKey(null); setImagePreview(null); } }}>
        <DialogContent className="sm:max-w-md rounded-2xl" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">添加钥匙</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium">小区 *</Label>
                <Input
                  className="h-11 rounded-xl text-base"
                  placeholder="如 翠湖花园"
                  value={form.community}
                  onChange={(e) => setForm({ ...form, community: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium">楼栋</Label>
                <Input
                  className="h-11 rounded-xl text-base"
                  placeholder="如 A栋"
                  value={form.building}
                  onChange={(e) => setForm({ ...form, building: e.target.value })}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium">房号 *</Label>
                <Input
                  className="h-11 rounded-xl text-base"
                  placeholder="如 101"
                  value={form.room}
                  onChange={(e) => setForm({ ...form, room: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium">钥匙编号 *</Label>
                <Select value={form.key_number} onValueChange={(v) => setForm({ ...form, key_number: v })}>
                  <SelectTrigger className="h-11 rounded-xl text-base">
                    <SelectValue placeholder="选择编号" />
                  </SelectTrigger>
                  <SelectContent className="max-h-60">
                    {availableKeyNumbers.length === 0 ? (
                      <SelectItem value="_empty" disabled>
                        已无可用编号
                      </SelectItem>
                    ) : (
                      availableKeyNumbers.map((n) => (
                        <SelectItem key={n} value={n}>
                          {n}
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium">类型</Label>
                <Select
                  value={form.key_type}
                  onValueChange={(v) => setForm({ ...form, key_type: v })}
                >
                  <SelectTrigger className="h-11 rounded-xl text-base">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="机械钥匙">🔑 机械钥匙</SelectItem>
                    <SelectItem value="密码卡片">💳 密码卡片</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium">数量</Label>
                <Input
                  type="number"
                  min={1}
                  className="h-11 rounded-xl text-base"
                  value={form.quantity}
                  onChange={(e) => setForm({ ...form, quantity: parseInt(e.target.value) || 1 })}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-sm font-medium">柜号</Label>
              <Input
                className="h-11 rounded-xl text-base"
                placeholder="可选"
                value={form.cabinet_number}
                onChange={(e) => setForm({ ...form, cabinet_number: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label className="text-sm font-medium">钥匙图片</Label>
              <div className="flex items-center gap-3">
                {imagePreview ? (
                  <div className="relative w-20 h-20 rounded-xl overflow-hidden border">
                    <img src={imagePreview} alt="预览" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      className="absolute top-1 right-1 w-5 h-5 bg-black/50 text-white rounded-full text-xs flex items-center justify-center"
                      onClick={() => { setImagePreview(null); setImageKey(null); }}
                    >
                      x
                    </button>
                  </div>
                ) : (
                  <label className="w-20 h-20 rounded-xl border-2 border-dashed border-gray-300 flex flex-col items-center justify-center cursor-pointer hover:border-emerald-400 hover:bg-emerald-50 transition-colors">
                    <span className="text-2xl text-gray-400">+</span>
                    <span className="text-[10px] text-gray-400 mt-0.5">上传图片</span>
                    <input
                      type="file"
                      accept="image/jpeg,image/png,image/webp,image/gif"
                      className="hidden"
                      onChange={handleImageUpload}
                      disabled={uploading}
                    />
                  </label>
                )}
                {uploading && <span className="text-sm text-muted-foreground">上传中...</span>}
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-sm font-medium">备注</Label>
              <Textarea
                className="rounded-xl text-base"
                rows={2}
                placeholder="可选，如密码信息等"
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <DialogClose asChild>
              <Button variant="outline" className="h-11 rounded-xl px-6 text-base">
                取消
              </Button>
            </DialogClose>
            <Button
              className="h-11 rounded-xl px-6 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-base"
              onClick={addKey}
              disabled={!form.community || !form.room || !form.key_number}
            >
              确认添加
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ─── 删除确认弹窗 ─── */}
      <Dialog open={!!showDelete} onOpenChange={() => setShowDelete(null)}>
        <DialogContent className="sm:max-w-sm rounded-2xl" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">确认删除</DialogTitle>
          </DialogHeader>
          <p className="text-muted-foreground py-2 text-base">
            确定要删除{" "}
            <span className="font-semibold text-foreground">
              {showDelete?.community} {showDelete?.building || ""} {showDelete?.room}
            </span>{" "}
            的钥匙吗？此操作不可撤销。
          </p>
          <DialogFooter className="gap-2">
            <DialogClose asChild>
              <Button variant="outline" className="h-11 rounded-xl px-6 text-base">
                取消
              </Button>
            </DialogClose>
            <Button
              variant="destructive"
              className="h-11 rounded-xl px-6 text-base font-semibold"
              onClick={() => showDelete && deleteKey(showDelete.id)}
            >
              确认删除
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
