import { NextRequest, NextResponse } from "next/server";
import { S3Storage } from "coze-coding-dev-sdk";

const storage = new S3Storage({
  endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL,
  accessKey: "",
  secretKey: "",
  bucketName: process.env.COZE_BUCKET_NAME,
  region: "cn-beijing",
});

export async function GET(request: NextRequest) {
  try {
    const key = request.nextUrl.searchParams.get("key");
    if (!key) {
      return NextResponse.json({ success: false, error: "缺少 key 参数" }, { status: 400 });
    }

    const url = await storage.generatePresignedUrl({ key, expireTime: 86400 });
    return NextResponse.json({ success: true, data: { url } });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : "获取图片链接失败";
    return NextResponse.json({ success: false, error: msg }, { status: 500 });
  }
}
