import { NextRequest, NextResponse } from "next/server";
import { getSupabaseClient } from "@/storage/database/supabase-client";

// GET /api/keys — 钥匙列表 + 统计
export async function GET(request: NextRequest) {
  try {
    const client = getSupabaseClient();
    const { searchParams } = new URL(request.url);

    const keyword = searchParams.get("keyword") || "";
    const status = searchParams.get("status") || "";
    const community = searchParams.get("community") || "";

    let query = client
      .from("keys")
      .select("id, community, building, room, key_number, key_type, quantity, status, cabinet_number, holder, notes, image_key, created_at, updated_at", { count: "exact" })
      .order("community", { ascending: true });

    if (status) query = query.eq("status", status);
    if (community) query = query.eq("community", community);
    if (keyword) {
      query = query.or(
        `community.ilike.%${keyword}%,room.ilike.%${keyword}%,holder.ilike.%${keyword}%,key_number.ilike.%${keyword}%`
      );
    }

    const { data, error, count } = await query;
    if (error) throw new Error(`查询失败: ${error.message}`);

    // 统计
    const [inStoreRes, borrowedRes, lostRes] = await Promise.all([
      client.from("keys").select("*", { count: "exact", head: true }).eq("status", "在店"),
      client.from("keys").select("*", { count: "exact", head: true }).eq("status", "借出"),
      client.from("keys").select("*", { count: "exact", head: true }).eq("status", "遗失"),
    ]);

    // 小区列表
    const { data: commData } = await client.from("keys").select("community");
    const communities = [...new Set((commData || []).map((c: { community: string }) => c.community))];

    return NextResponse.json({
      success: true,
      data: {
        keys: data || [],
        total: count ?? 0,
        stats: {
          total: count ?? 0,
          inStore: inStoreRes.count ?? 0,
          borrowed: borrowedRes.count ?? 0,
          lost: lostRes.count ?? 0,
        },
        communities,
      },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "未知错误";
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

// POST /api/keys — 添加钥匙
export async function POST(request: NextRequest) {
  try {
    const client = getSupabaseClient();
    const body = await request.json();

    const { community, building, room, key_number, key_type, quantity, cabinet_number, notes, image_key } = body;
    if (!community || !room) {
      return NextResponse.json({ success: false, error: "小区和房间号为必填" }, { status: 400 });
    }
    if (!key_number) {
      return NextResponse.json({ success: false, error: "钥匙编号为必填" }, { status: 400 });
    }

    // 检查钥匙编号是否重复
    const { data: existing } = await client
      .from("keys")
      .select("id")
      .eq("key_number", key_number)
      .maybeSingle();
    if (existing) {
      return NextResponse.json({ success: false, error: `钥匙编号 ${key_number} 已存在` }, { status: 400 });
    }

    const { data, error } = await client
      .from("keys")
      .insert({
        community,
        building: building || null,
        room,
        address: `${community}${building ? building : ""}${room}`,
        key_number: key_number || null,
        key_type: key_type || "机械钥匙",
        quantity: quantity || 1,
        cabinet_number: cabinet_number || null,
        notes: notes || null,
        image_key: image_key || null,
        status: "在店",
      })
      .select()
      .maybeSingle();

    if (error) {
      if (error.message.includes("duplicate key") || error.message.includes("unique constraint")) {
        return NextResponse.json({ success: false, error: `钥匙编号 ${key_number} 已存在` }, { status: 400 });
      }
      throw new Error(`添加失败: ${error.message}`);
    }

    return NextResponse.json({ success: true, data });
  } catch (err) {
    const message = err instanceof Error ? err.message : "未知错误";
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}
