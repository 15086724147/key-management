import { NextRequest, NextResponse } from "next/server";
import { getSupabaseClient } from "@/storage/database/supabase-client";

// POST /api/keys/batch — 批量操作
export async function POST(request: NextRequest) {
  try {
    const client = getSupabaseClient();
    const body = await request.json();
    const { ids, status, holder } = body;

    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      return NextResponse.json({ success: false, error: "请选择钥匙" }, { status: 400 });
    }
    if (!status) {
      return NextResponse.json({ success: false, error: "缺少状态" }, { status: 400 });
    }

    const updateData: Record<string, string | null> = {
      status,
      updated_at: new Date().toISOString(),
    };
    if (status === "借出" && holder) updateData.holder = holder;
    else if (status === "在店") updateData.holder = null;

    const { data, error } = await client
      .from("keys")
      .update(updateData)
      .in("id", ids)
      .select();

    if (error) throw new Error(`批量更新失败: ${error.message}`);

    // 静默记录日志
    const actionMap: Record<string, string> = { "借出": "借出", "在店": "归还", "遗失": "标记遗失" };
    const logs = ids.map((keyId: string) => ({
      key_id: keyId,
      action: actionMap[status] || "状态变更",
      from_status: null,
      to_status: status,
    }));
    await client.from("key_logs").insert(logs);

    return NextResponse.json({ success: true, data });
  } catch (err) {
    const message = err instanceof Error ? err.message : "未知错误";
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}
