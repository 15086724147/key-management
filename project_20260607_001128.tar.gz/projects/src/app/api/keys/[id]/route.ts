import { NextRequest, NextResponse } from "next/server";
import { getSupabaseClient } from "@/storage/database/supabase-client";

// PATCH /api/keys/[id] — 单个状态变更
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const client = getSupabaseClient();
    const { id } = await params;
    const body = await request.json();
    const { status, holder } = body;

    if (!status) {
      return NextResponse.json({ success: false, error: "缺少状态" }, { status: 400 });
    }

    const updateData: Record<string, string | null> = {
      status,
      updated_at: new Date().toISOString(),
    };
    if (status === "借出" && holder) updateData.holder = holder;
    else if (status === "在店") updateData.holder = null;

    const { data, error } = await client
      .from("keys")
      .update(updateData)
      .eq("id", id)
      .select()
      .maybeSingle();

    if (error) throw new Error(`更新失败: ${error.message}`);

    // 静默记录日志
    const actionMap: Record<string, string> = { "借出": "借出", "在店": "归还", "遗失": "标记遗失" };
    await client.from("key_logs").insert({
      key_id: id,
      action: actionMap[status] || "状态变更",
      from_status: null,
      to_status: status,
    });

    return NextResponse.json({ success: true, data });
  } catch (err) {
    const message = err instanceof Error ? err.message : "未知错误";
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

// DELETE /api/keys/[id] — 删除钥匙
export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const client = getSupabaseClient();
    const { id } = await params;

    const { error } = await client.from("keys").delete().eq("id", id);
    if (error) throw new Error(`删除失败: ${error.message}`);

    return NextResponse.json({ success: true });
  } catch (err) {
    const message = err instanceof Error ? err.message : "未知错误";
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}
