import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "钥匙管理",
  description: "房地产中介门店钥匙管理系统",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="zh-CN">
      <body className="antialiased min-h-screen bg-background">
        {children}
      </body>
    </html>
  );
}
