import { pgTable, serial, timestamp, varchar, integer, index } from "drizzle-orm/pg-core"
import { sql } from "drizzle-orm"

export const healthCheck = pgTable("health_check", {
	id: serial().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
});

// 钥匙表
export const keys = pgTable(
	"keys",
	{
		id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
		community: varchar("community", { length: 128 }).notNull(),
		building: varchar("building", { length: 64 }),
		room: varchar("room", { length: 64 }).notNull(),
		key_number: varchar("key_number", { length: 64 }),
		key_type: varchar("key_type", { length: 32 }).notNull().default("机械钥匙"),
		quantity: integer("quantity").notNull().default(1),
		status: varchar("status", { length: 16 }).notNull().default("在店"),
		cabinet_number: varchar("cabinet_number", { length: 32 }),
		holder: varchar("holder", { length: 64 }),
		notes: varchar("notes", { length: 512 }),
		image_key: varchar("image_key", { length: 512 }),
		created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
		updated_at: timestamp("updated_at", { withTimezone: true }),
	},
	(table) => [
		index("keys_status_idx").on(table.status),
		index("keys_community_idx").on(table.community),
		index("keys_holder_idx").on(table.holder),
	]
);

// 钥匙操作日志表（后台静默记录）
export const keyLogs = pgTable(
	"key_logs",
	{
		id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
		key_id: varchar("key_id", { length: 36 }).notNull().references(() => keys.id, { onDelete: "cascade" }),
		action: varchar("action", { length: 32 }).notNull(),
		from_status: varchar("from_status", { length: 16 }),
		to_status: varchar("to_status", { length: 16 }),
		reason: varchar("reason", { length: 512 }),
		created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		index("key_logs_key_id_idx").on(table.key_id),
		index("key_logs_created_at_idx").on(table.created_at),
	]
);
